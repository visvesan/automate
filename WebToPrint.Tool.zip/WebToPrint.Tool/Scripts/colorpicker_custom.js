$(document).ready(function() {

    $('#font-color').ColorPicker({
        color: '#0000ff',
        onShow: function (colpkr) {
            $(colpkr).fadeIn(500);
            return false;
        },
        onHide: function (colpkr) {
            $(colpkr).fadeOut(500);
            return false;
        },
        onSubmit: function(hsb, hex, rgb, el) {
            $(el).val(hex);
            $(el).ColorPickerHide();

        },
        onBeforeShow: function () {
            $(this).ColorPickerSetColor(this.value);
        },
        onChange: function (hsb, hex, rgb) {
            $('#font-color').css('backgroundColor', '#' + hex);
            var activeObject = canvas.getActiveObject();
            global_text = canvas.getActiveObject();
            if (activeObject && activeObject.type === 'text') {
                activeObject.fill = hex;
                canvas.renderAll();
            }
        }
    });

    window.set_color_picker = function(rgb){
        $('#font-color').ColorPickerSetColor(rgb);
        $('#font-color').css('backgroundColor', (new fabric.Color(rgb)).toRgb());
    }

});