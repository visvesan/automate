var bind_canvas_listeners = function(canvas){
    var removeEl = function(){
        canvas.getActiveObject().remove();
    };

    $('#remove_el_btn').on('click',removeEl);

    document.onkeydown = function(e)
    {
        if($(':focus').length == 0){
            var KeyID = event.keyCode;
            switch(KeyID)
            {
                case 8:
                    removeEl();
                    e.preventDefault();
                    break;
                case 46:
                    removeEl();
                    e.preventDefault();
                    break;
                default:
                    break;
            }
        }
    }

    canvas.observe('object:selected', function(o){
        if (o.target.type === 'text') {
            var font_style = o.target.fontStyle + " " + o.target.fontWeight;
            $('#selected_text').val(o.target.text);
            set_color_picker(o.target.fill);
            $("#text-align").val(o.target.originX);
            $("#font-style").val(font_style);
            $("#font-family").val(o.target.fontFamily);
            $("#font-size").val(o.target.fontSize);
        }
    });

    $('#selected_text').click(function(){
        $('#selected_text').val('');
        canvas.deactivateAll();
        canvas.renderAll();
    });

    $('#selected_text').on('keyup', function(t){
        var activeObject = canvas.getActiveObject();
        if (activeObject) {
            if (!this.value) {
                canvas.discardActiveObject();
            }
            else {
                activeObject.setText(this.value);
            }
            canvas.renderAll();
        }
    });

    $('#to_png').on('click',function(e){
		alert('Png');
        canvas.deactivateAll();
        canvas.renderAll();
        var png_string = canvas.toDataURL('png');
        window.open(png_string);
    });

    $('#text-align').change(function(t){
        var activeObject = canvas.getActiveObject();
        if (activeObject && activeObject.type === 'text') {
            var original_center = activeObject.getCenterPoint();
            activeObject.originX = $('#text-align').val();
            activeObject.setPositionByOrigin(original_center);
            canvas.renderAll();
        }
    });

    $('#font-size').on('keyup', function(t){
        var activeObject = canvas.getActiveObject();
        if (activeObject && activeObject.type === 'text') {
            if($(this).val() >= 4){
                activeObject.setFontSize(parseInt(this.value, 10));
                canvas.renderAll();
            }
        }
    });

    $('#font-style').change(function(){
        var activeObject = canvas.getActiveObject();
        if (activeObject && activeObject.type === 'text') {
            switch(this.value){
                case "Normal":
                    activeObject.fontWeight = "Normal";
                    activeObject.fontStyle = "Normal";
                    break;
                case "Italic":
                    activeObject.fontWeight = "Normal";
                    activeObject.fontStyle = "Italic";
                    break;
                case "Normal Bold":
                    activeObject.fontWeight = "Bold";
                    activeObject.fontStyle = "Normal";
                    break;
                case "Italic Bold":
                    activeObject.fontWeight = "Bold";
                    activeObject.fontStyle = "Italic";
                    break;
            }
            canvas.renderAll();
        }
    });

    $('#font-family').change(function(){
        var activeObject = canvas.getActiveObject();
        if (activeObject && activeObject.type === 'text') {
            activeObject.fontFamily = this.value;
            canvas.renderAll();
        }
    });
}